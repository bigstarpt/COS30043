<template>
  <div class="container">
    <h1>Welcome {{ firstName }} {{ lastName }}!</h1>
    <p>What is your name?</p>  
    <label for="firstName">First Name: </label>
    <input id="firstname" type="text" v-model="firstName"/>
    <br>
    <label for="lastName">Last Name: </label>
    <input id="lastname" type="text" v-model="lastName"/>
    <br/>
    <input class="form-check-input" type="radio" id="ocean" value="Ocean" v-model="picked" />
    <label for="ocean">Ocean</label>
    <input class="form-check-input" type="radio" id="mountain" value="Mountain" v-model="picked" />
    <label for="mountain">Mountain</label>
    <div class="row">
      <div class="col align-self-center">
        <template v-if="picked === 'Ocean'">
          <img class="landscape" src="../assets/ocean.jpg" />
        </template>
        <template v-if="picked === 'Mountain'">
          <img class="landscape" src="../assets/mountain.jpg" />
        </template>
      </div>
    </div>   
  </div>
</template>

<script>
export default {
  name: 'HomeSection',
  data() {
    return {
      firstName: '',
      lastName: '',
      picked: ''
    };
  },
};
</script>

<style scoped>
  .landscape{
    width: 400px;
    height: 300px;
  }
</style>
