<template>
  <div>
    <span>Add new task here: </span>
    <div class="d-flex justify-content-center" >      
        <input
        class="form-control w-25"
        type="text"
        id="strStatus"
        v-model="strStatus"      
        />
        <button type="button" class="btn btn-success mx-1" v-on:click="add">Success</button>
    </div>     
    <div class = "d-flex justify-content-center">
      <ul class="list-group list-group-flush w-25">
        <li class="list-group-item mb-3"
        v-for="(s,index) in statPosts"
        :key="index"
        >
        {{s}}<button type="button" v-on:click="remove(index)" class="btn btn-danger" >Danger</button>
        </li>        
     </ul>
    </div>    
  </div>
</template>

<script>
export default {
  name: 'TasksList',
  data() {
    return {
      statPosts: [],
      strStatus: "",
    };
  },
  methods: {
    add() {
      // push status into statPosts array
      this.statPosts.push(this.strStatus);
    },
    remove(index) {
      // delete status from statPost using index
      this.statPosts.splice(index, 1);
    },
  },
};
</script>

  

<style >

</style>