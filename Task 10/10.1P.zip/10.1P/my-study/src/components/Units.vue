<template>
  <table class="table table-bordered container">
        <thead>
        <tr>
          <th>Code</th>
          <th>Description</th>
          <th>Cp</th>
          <th>Type</th>
        </tr>
        </thead>
       <tbody> 
        <tr v-for="unit in units" :key='unit.code'>
          <td>{{ unit.code }}</td>
          <td>{{ unit.desc }}</td>
          <td>{{ unit.cp }}</td>
          <td>{{ unit.type }}</td>
        </tr>
        </tbody>
      </table>
</template>

<script>
import Units from "../assets/units.json"; // your JSON file is under assets
export default {
  name: 'UnitsList',
  data() {
    return {
      units: Units,
    };
  },
};
</script>


<style />